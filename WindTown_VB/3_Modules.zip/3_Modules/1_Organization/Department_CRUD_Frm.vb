Public Class Department_CRUD_Frm

    Protected _data As Department


    Public Sub New(data As Department, Optional isCreate As Boolean = False)

        InitializeComponent()

        Me._data = data
        Me.isCreate = isCreate

        ui_status.DataSource = New BindingSource(Department.status_Dict, Nothing)
        ui_status.DisplayMember = "Value"
        ui_status.ValueMember = "Key"

        Me.Text = If(isCreate, "Thêm phòng ban", "Chi tiết phòng ban")

        BindDataToUI()

        tool_save.Enabled = False
    End Sub
    Protected Overrides Sub BindDataToUI()
        ui_code.Text = _data.code
        ui_name.Text = _data.name
        ui_note.Text = _data.note
        ui_status.SelectedValue = _data.status
    End Sub

    Protected Overrides Function SyncUIToData() As Boolean

        If String.IsNullOrWhiteSpace(ui_code.Text) Then
            MessageBox.Show("Mã phòng ban không hợp lệ!")
            ui_code.Focus()
            Return False
        End If
        If AppServices.Instance.DepartmentSV.IsCodeDuplicate(ui_code.Text.Trim(), If(isCreate, 0, _data.id)) Then
            MessageBox.Show("Mã phòng ban đã tồn tại.")
            Return False
        End If
        If String.IsNullOrWhiteSpace(ui_name.Text) Then
            MessageBox.Show("Tên phòng ban không hợp lệ!")
            ui_name.Focus()
            Return False
        End If


        _data.code = ui_code.Text.Trim()
        _data.name = ui_name.Text.Trim()
        _data.note = ui_note.Text
        _data.status = CInt(ui_status.SelectedValue)

        Return True
    End Function

    Protected Overrides Sub DataChanged() Handles ui_code.TextChanged,
                                 ui_name.TextChanged,
                                 ui_note.TextChanged,
                                 ui_status.SelectedIndexChanged

        tool_save.Enabled = True
    End Sub

End Class