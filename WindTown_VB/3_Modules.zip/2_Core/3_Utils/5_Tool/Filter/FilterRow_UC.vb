' ============================================================
'  FilterRow_UC.vb — 1 dòng lọc: Field + Operator + Value
'  Design tay hoàn toàn, không cần Designer
' ============================================================
Public Class FilterRow_UC
    Inherits Panel

    Private ReadOnly _fields As List(Of FilterHelper.FieldInfo)
    Private _cboField As ComboBox
    Private _cboOp As ComboBox
    Private _pnlValue1 As Panel
    Private _pnlValue2 As Panel
    Private _lblBetween As Label
    Private _btnRemove As Button

    Public Sub New(fields As List(Of FilterHelper.FieldInfo))
        _fields = fields

        ' ✅ Set size TRƯỚC khi add controls
        Me.Height = 38
        Me.BorderStyle = BorderStyle.FixedSingle
        Me.Padding = New Padding(2)
        Me.BackColor = Color.FromArgb(250, 251, 253)

        BuildRow()

        ' ✅ Gán SelectedIndex SAU khi đã BuildRow xong
        ' KHÔNG dùng With để gán DataSource — gán riêng sau

    End Sub

    Private Sub BuildRow()
        ' ── Field ComboBox ─────────────────────────────────────
        _cboField = New ComboBox() With {
            .DropDownStyle = ComboBoxStyle.DropDownList,
            .Font = New Font("Segoe UI", 9.0!),
            .Location = New Point(4, 5),
            .Size = New Size(155, 26)
        }
        ' ✅ Gán DataSource riêng, KHÔNG trong With
        _cboField.DataSource = _fields
        _cboField.DisplayMember = "DisplayName"
        _cboField.ValueMember = "PropName"
        ' ✅ AddHandler SAU khi gán DataSource để tránh fire khi bind
        AddHandler _cboField.SelectedIndexChanged, AddressOf OnFieldChanged

        ' ── Operator ComboBox ──────────────────────────────────
        _cboOp = New ComboBox() With {
            .DropDownStyle = ComboBoxStyle.DropDownList,
            .Font = New Font("Segoe UI", 9.0!),
            .Location = New Point(165, 5),
            .Size = New Size(105, 26)
        }
        AddHandler _cboOp.SelectedIndexChanged, AddressOf OnOpChanged

        ' ── Value 1 ───────────────────────────────────────────
        _pnlValue1 = New Panel() With {
            .Location = New Point(276, 5),
            .Size = New Size(155, 26),
            .BorderStyle = BorderStyle.None
        }

        ' ── Label "đến" ───────────────────────────────────────
        _lblBetween = New Label() With {
            .Text = "đến",
            .Location = New Point(437, 9),
            .Size = New Size(28, 18),
            .Font = New Font("Segoe UI", 8.5!),
            .Visible = False,
            .TextAlign = ContentAlignment.MiddleLeft
        }

        ' ── Value 2 (for between) ─────────────────────────────
        _pnlValue2 = New Panel() With {
            .Location = New Point(470, 5),
            .Size = New Size(155, 26),
            .BorderStyle = BorderStyle.None,
            .Visible = False
        }

        ' ── Remove button ─────────────────────────────────────
        _btnRemove = New Button() With {
            .Text = "×",
            .Font = New Font("Segoe UI", 10.0!, FontStyle.Bold),
            .Location = New Point(632, 4),
            .Size = New Size(26, 26),
            .FlatStyle = FlatStyle.Flat,
            .ForeColor = Color.FromArgb(200, 50, 50),
            .BackColor = Color.Transparent,
            .Cursor = Cursors.Hand,
            .TabStop = False
        }
        _btnRemove.FlatAppearance.BorderSize = 0
        _btnRemove.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 230, 230)
        AddHandler _btnRemove.Click, AddressOf OnRemoveClick

        Me.Controls.AddRange({_cboField, _cboOp, _pnlValue1, _lblBetween, _pnlValue2, _btnRemove})
    End Sub

    ' ── Khi chọn Field ────────────────────────────────────────
    Private Sub OnFieldChanged(sender As Object, e As EventArgs)
        Dim fi = TryCast(_cboField.SelectedItem, FilterHelper.FieldInfo)
        If fi Is Nothing Then Return

        ' Cập nhật operators
        _cboOp.Items.Clear()
        For Each op In FilterHelper.GetOperators(fi.PropType)
            _cboOp.Items.Add(op)
        Next
        _cboOp.SelectedIndex = 0

        ' Sinh value control
        _pnlValue1.Controls.Clear()
        _pnlValue2.Controls.Clear()

        Dim ctrl1 = CreateValueControl(fi.PropType)
        ctrl1.Dock = DockStyle.Fill
        _pnlValue1.Controls.Add(ctrl1)

        Dim ctrl2 = CreateValueControl(fi.PropType)
        ctrl2.Dock = DockStyle.Fill
        _pnlValue2.Controls.Add(ctrl2)
    End Sub

    ' ── Khi chọn Operator ────────────────────────────────────
    Private Sub OnOpChanged(sender As Object, e As EventArgs)
        Dim isBetween = (_cboOp.SelectedItem?.ToString().ToLower() = "between")
        _pnlValue2.Visible = isBetween
        _lblBetween.Visible = isBetween
    End Sub

    ' ── Xóa row ───────────────────────────────────────────────
    Private Sub OnRemoveClick(sender As Object, e As EventArgs)
        Dim p = Me.Parent
        If p IsNot Nothing Then
            p.Controls.Remove(Me)
        End If
        Me.Dispose()
    End Sub

    ' ── Sinh Control theo kiểu dữ liệu ───────────────────────
    Private Function CreateValueControl(propType As Type) As Control
        Dim t = If(Nullable.GetUnderlyingType(propType), propType)

        If t = GetType(String) Then
            Return New TextBox() With {.Font = New Font("Segoe UI", 9.0!)}

        ElseIf t = GetType(DateTime) Then
            Return New DateTimePicker() With {
                .Format = DateTimePickerFormat.Short,
                .Font = New Font("Segoe UI", 9.0!)
            }

        ElseIf t = GetType(Boolean) Then
            Dim cbo As New ComboBox() With {
                .DropDownStyle = ComboBoxStyle.DropDownList,
                .Font = New Font("Segoe UI", 9.0!)
            }
            cbo.Items.AddRange({"True", "False"})
            cbo.SelectedIndex = 0
            Return cbo

        Else
            ' Integer, Decimal, Double...
            Return New NumericUpDown() With {
                .Font = New Font("Segoe UI", 9.0!),
                .Maximum = 999999999,
                .Minimum = -999999999,
                .DecimalPlaces = 0
            }
        End If
    End Function

    ' ── Lấy giá trị từ Panel ─────────────────────────────────
    Private Function GetControlValue(pnl As Panel) As Object
        If pnl.Controls.Count = 0 Then Return Nothing
        Dim ctrl = pnl.Controls(0)
        If TypeOf ctrl Is TextBox Then Return CType(ctrl, TextBox).Text
        If TypeOf ctrl Is DateTimePicker Then Return CType(ctrl, DateTimePicker).Value
        If TypeOf ctrl Is NumericUpDown Then Return CType(ctrl, NumericUpDown).Value
        If TypeOf ctrl Is ComboBox Then
            Return (CType(ctrl, ComboBox).SelectedItem?.ToString() = "True")
        End If
        Return Nothing
    End Function

    ' ── Public: lấy FilterModel từ row này ───────────────────
    Public Function GetFilter() As FilterModel
        Dim fi = TryCast(_cboField.SelectedItem, FilterHelper.FieldInfo)
        If fi Is Nothing Then Return Nothing
        If String.IsNullOrWhiteSpace(_cboOp.SelectedItem?.ToString()) Then Return Nothing

        Return New FilterModel With {
            .Field = fi.PropName,
            .Opera = _cboOp.SelectedItem.ToString(),
            .Value1 = GetControlValue(_pnlValue1),
            .Value2 = If(_pnlValue2.Visible, GetControlValue(_pnlValue2), Nothing)
        }
    End Function

End Class