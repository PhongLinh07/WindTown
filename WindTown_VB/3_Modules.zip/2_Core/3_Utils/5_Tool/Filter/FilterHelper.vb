Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations
Imports System.Reflection

Public Module FilterHelper

    Public Class FieldInfo
        Public Property PropName As String      ' tên property thật: "name", "code"
        Public Property DisplayName As String   ' tên hiển thị: "Tên phòng ban"
        Public Property PropType As Type        ' kiểu dữ liệu thật
        Public Property Order As Integer        ' thứ tự hiển thị
    End Class

    ' Operator tương ứng với từng kiểu dữ liệu
    Public Function GetOperators(propType As Type) As List(Of String)
        Dim t = If(Nullable.GetUnderlyingType(propType), propType)
        If t = GetType(String) Then
            Return New List(Of String) From {"contains", "=", "starts with", "ends with"}
        ElseIf t = GetType(DateTime) Then
            Return New List(Of String) From {"=", ">", "<", ">=", "<=", "between"}
        ElseIf t = GetType(Boolean) Then
            Return New List(Of String) From {"="}
        Else
            Return New List(Of String) From {"=", "<>", ">", "<", ">=", "<=", "between"}
        End If
    End Function


    Public Function GetFilterableFields(modelType As Type) As List(Of FieldInfo)
        Dim result As New List(Of FieldInfo)()

        For Each prop In modelType.GetProperties()
            ' Bỏ qua Browsable(False)
            Dim browsAttr = prop.GetCustomAttribute(Of BrowsableAttribute)()
            If browsAttr IsNot Nothing AndAlso Not browsAttr.Browsable Then Continue For

            ' Phải có DisplayName mới hiện ra
            Dim dispNameAttr = prop.GetCustomAttribute(Of DisplayNameAttribute)()
            If dispNameAttr Is Nothing Then Continue For

            ' Lấy Order
            Dim dispAttr = prop.GetCustomAttribute(Of DisplayAttribute)()
            Dim order = If(dispAttr IsNot Nothing, dispAttr.Order, 999)

            ' Xác định kiểu thật để chọn Control phù hợp
            Dim propType = If(Nullable.GetUnderlyingType(prop.PropertyType), prop.PropertyType)

            result.Add(New FieldInfo With {
                .PropName = prop.Name,
                .DisplayName = dispNameAttr.DisplayName,
                .PropType = propType,
                .Order = order
            })
        Next

        Return result.OrderBy(Function(x) x.Order).ToList()
    End Function

    ' Apply danh sách FilterModel lên List(Of T) — lọc in-memory
    Public Function ApplyFilters(Of T)(source As IEnumerable(Of T),
                                       filters As List(Of FilterModel)) As List(Of T)
        If filters Is Nothing OrElse filters.Count = 0 Then Return source.ToList()

        Dim result = source
        For Each f In filters
            If f Is Nothing OrElse String.IsNullOrWhiteSpace(f.Field) Then Continue For
            result = result.Where(Function(item) MatchFilter(item, f))
        Next
        Return result.ToList()
    End Function

    ' Kiểm tra 1 item có khớp 1 FilterModel không
    Private Function MatchFilter(Of T)(item As T, f As FilterModel) As Boolean
        Try
            Dim prop = GetType(T).GetProperty(f.Field)
            If prop Is Nothing Then Return True

            Dim rawVal = prop.GetValue(item)
            Dim propType = If(Nullable.GetUnderlyingType(prop.PropertyType), prop.PropertyType)

            If propType = GetType(String) Then
                Dim s = If(rawVal?.ToString(), "").ToLower()
                Dim v = If(f.Value1?.ToString(), "").ToLower()
                Select Case f.Opera.ToLower()
                    Case "contains" : Return s.Contains(v)
                    Case "starts with" : Return s.StartsWith(v)
                    Case "ends with" : Return s.EndsWith(v)
                    Case "=" : Return s = v
                    Case Else : Return True
                End Select

            ElseIf propType = GetType(DateTime) Then
                Dim d = CType(rawVal, DateTime)
                Dim v1 = CType(f.Value1, DateTime)
                Select Case f.Opera.ToLower()
                    Case "=" : Return d.Date = v1.Date
                    Case ">" : Return d > v1
                    Case "<" : Return d < v1
                    Case ">=" : Return d >= v1
                    Case "<=" : Return d <= v1
                    Case "between"
                        Dim v2 = CType(f.Value2, DateTime)
                        Return d >= v1 AndAlso d <= v2
                    Case Else : Return True
                End Select

            ElseIf propType = GetType(Boolean) Then
                Return CBool(rawVal) = CBool(f.Value1)

            Else
                Dim d1 = CDec(rawVal)
                Dim v1 = CDec(f.Value1)
                Select Case f.Opera
                    Case "=" : Return d1 = v1
                    Case "<>" : Return d1 <> v1
                    Case ">" : Return d1 > v1
                    Case "<" : Return d1 < v1
                    Case ">=" : Return d1 >= v1
                    Case "<=" : Return d1 <= v1
                    Case "between"
                        Dim v2 = CDec(f.Value2)
                        Return d1 >= v1 AndAlso d1 <= v2
                    Case Else : Return True
                End Select
            End If
        Catch
            Return True
        End Try
        Return True
    End Function

End Module

' ============================================================
'  FilterModel — dữ liệu 1 điều kiện lọc
' ============================================================
Public Class FilterModel
    Public Property Field As String
    Public Property Opera As String
    Public Property Value1 As Object
    Public Property Value2 As Object   ' dùng cho "between"
End Class