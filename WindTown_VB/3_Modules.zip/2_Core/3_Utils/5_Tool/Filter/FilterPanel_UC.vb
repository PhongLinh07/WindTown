' ============================================================
'  FilterPanel_UC.vb — Panel lọc động
'  Dock = Top, nhúng vào BaseList_UC
' ============================================================
Public Class FilterPanel_UC
    Inherits Panel

    Private ReadOnly _fields As List(Of FilterHelper.FieldInfo)
    Private _pnlRows As Panel       ' chứa các FilterRow xếp dọc
    Private _pnlToolbar As Panel    ' chứa các nút
    Private _lblStatus As Label

    Public Event FilterApplied(filters As List(Of FilterModel))
    Public Event FilterCleared()

    Private Const ROW_H As Integer = 42
    Private Const TOOLBAR_H As Integer = 36

    Public Sub New(modelType As Type)
        _fields = FilterHelper.GetFilterableFields(modelType)

        Me.Dock = DockStyle.Top
        Me.Visible = False
        Me.Height = 0
        Me.BackColor = Color.FromArgb(240, 244, 250)
        Me.Padding = New Padding(4, 2, 4, 4)

        BuildToolbar()
        BuildRowPanel()
    End Sub

    ' ── Toolbar: Add / Apply / Clear / Status ─────────────────
    Private Sub BuildToolbar()
        _pnlToolbar = New Panel() With {
            .Dock = DockStyle.Top,
            .Height = TOOLBAR_H,
            .BackColor = Color.Transparent
        }

        Dim btnAdd As New Button() With {
            .Text = "+ Điều kiện",
            .Font = New Font("Segoe UI", 9.0!),
            .Size = New Size(90, 26),
            .Location = New Point(4, 4),
            .FlatStyle = FlatStyle.Flat,
            .Cursor = Cursors.Hand
        }
        btnAdd.FlatAppearance.BorderColor = Color.FromArgb(160, 180, 220)
        AddHandler btnAdd.Click, AddressOf OnAddRow

        Dim btnApply As New Button() With {
            .Text = "✓ Áp dụng",
            .Font = New Font("Segoe UI", 9.0!, FontStyle.Bold),
            .Size = New Size(90, 26),
            .Location = New Point(100, 4),
            .FlatStyle = FlatStyle.Flat,
            .BackColor = Color.FromArgb(33, 115, 220),
            .ForeColor = Color.White,
            .Cursor = Cursors.Hand
        }
        btnApply.FlatAppearance.BorderSize = 0
        AddHandler btnApply.Click, AddressOf OnApply

        Dim btnClear As New Button() With {
            .Text = "× Xóa lọc",
            .Font = New Font("Segoe UI", 9.0!),
            .Size = New Size(80, 26),
            .Location = New Point(196, 4),
            .FlatStyle = FlatStyle.Flat,
            .Cursor = Cursors.Hand
        }
        btnClear.FlatAppearance.BorderColor = Color.FromArgb(200, 100, 100)
        btnClear.ForeColor = Color.FromArgb(180, 50, 50)
        AddHandler btnClear.Click, AddressOf OnClear

        _lblStatus = New Label() With {
            .Text = "",
            .Font = New Font("Segoe UI", 8.5!, FontStyle.Italic),
            .Location = New Point(284, 8),
            .AutoSize = True,
            .ForeColor = Color.FromArgb(60, 110, 190)
        }

        _pnlToolbar.Controls.AddRange({btnAdd, btnApply, btnClear, _lblStatus})
        Me.Controls.Add(_pnlToolbar)
    End Sub

    ' ── Panel chứa các FilterRow ──────────────────────────────
    Private Sub BuildRowPanel()
        _pnlRows = New Panel() With {
            .Dock = DockStyle.Fill,
            .AutoScroll = False,
            .BackColor = Color.Transparent
        }
        Me.Controls.Add(_pnlRows)
        _pnlRows.BringToFront()  ' ✅ Fill phải nằm trước Top
    End Sub

    ' ── Thêm row ──────────────────────────────────────────────
    Private Sub OnAddRow(sender As Object, e As EventArgs)
        Dim row As New FilterRow_UC(_fields)
        row.Width = _pnlRows.ClientSize.Width - 4
        row.Left = 2
        row.Top = GetRowCount() * ROW_H
        _pnlRows.Controls.Add(row)
        UpdateHeight()
    End Sub

    Private Function GetRowCount() As Integer
        Return _pnlRows.Controls.OfType(Of FilterRow_UC)().Count()
    End Function

    ' ── Áp dụng filter ────────────────────────────────────────
    Private Sub OnApply(sender As Object, e As EventArgs)
        Dim filters As New List(Of FilterModel)()
        For Each row In _pnlRows.Controls.OfType(Of FilterRow_UC)()
            Dim f = row.GetFilter()
            If f IsNot Nothing Then filters.Add(f)
        Next
        _lblStatus.Text = If(filters.Count > 0, $"Đang lọc: {filters.Count} điều kiện", "")
        RaiseEvent FilterApplied(filters)
    End Sub

    ' ── Xóa filter ────────────────────────────────────────────
    Private Sub OnClear(sender As Object, e As EventArgs)
        _pnlRows.Controls.Clear()
        _lblStatus.Text = ""
        UpdateHeight()
        RaiseEvent FilterCleared()
    End Sub

    ' ── Tính lại chiều cao ────────────────────────────────────
    Private Sub UpdateHeight()
        Dim rowCount = GetRowCount()
        Me.Height = TOOLBAR_H + (rowCount * ROW_H) + 8
    End Sub

    ' ── Toggle show/hide ──────────────────────────────────────
    Public Sub Toggle()
        If Me.Visible Then
            Me.Visible = False
            Me.Height = 0
        Else
            Me.Visible = True
            ' Tự thêm 1 row nếu chưa có
            If GetRowCount() = 0 Then OnAddRow(Nothing, Nothing)
            UpdateHeight()
        End If
    End Sub

End Class