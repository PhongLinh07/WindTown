Imports Microsoft.EntityFrameworkCore

Public Class GenericRepository(Of T As Class)

    Protected ReadOnly _ctx As AppDbContext

    Sub New(ctx As AppDbContext)
        _ctx = ctx
    End Sub

    ' ✅ Override tại Repository con để khai báo Include
    Protected Overridable Function BaseQuery() As IQueryable(Of T)
        Return _ctx.Set(Of T)()
    End Function

    ' ✅ Cổng thực thi duy nhất — mọi truy vấn đi qua đây
    Private Function Execute(filter As SqlFilter(Of T)) As IQueryable(Of T)
        Return filter.Apply(BaseQuery())
    End Function

    ' ─────────────────────────────────────────
    ' GetList — luôn loại soft-delete
    ' ─────────────────────────────────────────
    Public Overridable Function GetList() As List(Of T)
        Dim f = SqlFilter(Of T).Default() _
            .Add(Function(x) EF.Property(Of Integer)(x, "status") <> -1)
        Return Execute(f).ToList()
    End Function

    ' ─────────────────────────────────────────
    ' GetById — load 1 bản ghi, kèm soft-delete check
    ' ─────────────────────────────────────────
    Public Overridable Function GetById(id As Integer) As T
        Dim f = SqlFilter(Of T).Default() _
            .Add(Function(x) EF.Property(Of Integer)(x, "status") <> -1) _
            .Add(Function(x) EF.Property(Of Integer)(x, "id") = id)
        Return Execute(f).FirstOrDefault()
    End Function

    ' ─────────────────────────────────────────
    ' Search — filter linh hoạt từ UI
    ' ─────────────────────────────────────────
    Public Function Search(filter As SqlFilter(Of T)) As List(Of T)
        Return Execute(filter).ToList()
    End Function

    ' ─────────────────────────────────────────
    ' CRUD
    ' ─────────────────────────────────────────
    Public Function Insert(entity As T) As Boolean
        Try
            _ctx.Set(Of T)().Add(entity)
            _ctx.SaveChanges()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Update(entity As T) As Boolean
        Try
            ' ✅ Kiểm tra xem entity có đang được track chưa
            Dim entry = _ctx.Entry(entity)

            If entry.State = EntityState.Detached Then
                ' Entity từ bên ngoài vào — attach và đánh dấu Modified
                _ctx.Set(Of T)().Attach(entity)
                entry.State = EntityState.Modified
            End If

            _ctx.SaveChanges()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    ' Soft-delete — chỉ đổi status = -1, không xóa thật
    Public Function Delete(id As Integer) As Boolean
        Try
            Dim entity = _ctx.Set(Of T)().Find(id)
            If entity Is Nothing Then Return False
            _ctx.Entry(entity).Property("status").CurrentValue = -1
            _ctx.SaveChanges()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class