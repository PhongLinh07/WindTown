Public Interface IBaseService
    Function Execute(intent As DataIntent, Optional data As Object = Nothing) As ServiceResponse(Of Object)
End Interface

Public Class BaseService(Of T As {BaseEntity, New})
    Implements IBaseService

    Protected _repo As GenericRepository(Of T)
    Protected _ctx As AppDbContext

    Public Sub New()
        _ctx = New AppDbContext()
        _repo = New GenericRepository(Of T)(_ctx)
    End Sub

    Public Overridable Function Execute(intent As DataIntent, Optional data As Object = Nothing) As ServiceResponse(Of Object) Implements IBaseService.Execute
        Try
            Select Case intent

                Case DataIntent.GetList
                    Return ServiceResponse(Of Object).Success(_repo.GetList())

                Case DataIntent.Insert
                    Try
                        Dim result = _repo.Insert(DirectCast(data, T))
                        Return ServiceResponse(Of Object).Success(result, "Thêm mới thành công!")
                    Catch ex As Exception
                        Return ServiceResponse(Of Object).Fail("Không thể thêm: " & ex.Message, ex)
                    End Try

                Case DataIntent.Update
                    Try
                        Dim result = _repo.Update(DirectCast(data, T))
                        Return ServiceResponse(Of Object).Success(result, "Cập nhật thành công!")
                    Catch ex As Exception
                        Return ServiceResponse(Of Object).Fail("Không thể cập nhật: " & ex.Message, ex)
                    End Try

                Case DataIntent.SoftDeleteMany
                    Try
                        Dim items = DirectCast(data, IEnumerable(Of T))
                        For Each item In items
                            _repo.Delete(item.id)
                        Next
                        Return ServiceResponse(Of Object).Success(True, "Xóa thành công!")
                    Catch ex As Exception
                        Return ServiceResponse(Of Object).Fail("Không thể xóa: " & ex.Message, ex)
                    End Try

                Case Else
                    Return ServiceResponse(Of Object).Fail("Yêu cầu không hợp lệ")

            End Select
        Catch ex As Exception
            Return ServiceResponse(Of Object).Fail("Lỗi hệ thống: " & ex.Message, ex)
        End Try
    End Function

End Class