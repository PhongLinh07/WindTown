﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmHopDong
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmHopDong))
        Me.tlpnlMain = New System.Windows.Forms.TableLayoutPanel()
        Me.tlpDashboard = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.dtpkDenNgay = New System.Windows.Forms.DateTimePicker()
        Me.dtpkTuNgay = New System.Windows.Forms.DateTimePicker()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.tbxSearch = New System.Windows.Forms.TextBox()
        Me.cbbxThoiGianHD = New System.Windows.Forms.ComboBox()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.btnSuaHangLoat = New System.Windows.Forms.Button()
        Me.btnXoaHD = New System.Windows.Forms.Button()
        Me.btnSuaHD = New System.Windows.Forms.Button()
        Me.btnXuatHD = New System.Windows.Forms.Button()
        Me.btnThemHD = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cbbxTrangThai = New System.Windows.Forms.ComboBox()
        Me.cbbxBoPhan = New System.Windows.Forms.ComboBox()
        Me.dtgvDSHopDong = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tlpnlMain.SuspendLayout()
        Me.tlpDashboard.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dtgvDSHopDong, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tlpnlMain
        '
        Me.tlpnlMain.ColumnCount = 1
        Me.tlpnlMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpnlMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpnlMain.Controls.Add(Me.tlpDashboard, 0, 0)
        Me.tlpnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpnlMain.Location = New System.Drawing.Point(0, 0)
        Me.tlpnlMain.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.tlpnlMain.Name = "tlpnlMain"
        Me.tlpnlMain.RowCount = 1
        Me.tlpnlMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpnlMain.Size = New System.Drawing.Size(1040, 665)
        Me.tlpnlMain.TabIndex = 1
        '
        'tlpDashboard
        '
        Me.tlpDashboard.BackColor = System.Drawing.Color.Gainsboro
        Me.tlpDashboard.ColumnCount = 4
        Me.tlpDashboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpDashboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.95753!))
        Me.tlpDashboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.94595!))
        Me.tlpDashboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpDashboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpDashboard.Controls.Add(Me.Panel6, 3, 1)
        Me.tlpDashboard.Controls.Add(Me.Panel5, 2, 1)
        Me.tlpDashboard.Controls.Add(Me.Panel4, 1, 1)
        Me.tlpDashboard.Controls.Add(Me.pnlHeader, 0, 0)
        Me.tlpDashboard.Controls.Add(Me.Panel2, 0, 1)
        Me.tlpDashboard.Controls.Add(Me.dtgvDSHopDong, 0, 2)
        Me.tlpDashboard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpDashboard.Location = New System.Drawing.Point(2, 3)
        Me.tlpDashboard.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.tlpDashboard.Name = "tlpDashboard"
        Me.tlpDashboard.RowCount = 3
        Me.tlpDashboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 77.0!))
        Me.tlpDashboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.39286!))
        Me.tlpDashboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.60714!))
        Me.tlpDashboard.Size = New System.Drawing.Size(1036, 659)
        Me.tlpDashboard.TabIndex = 2
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.White
        Me.Panel6.Controls.Add(Me.tbxSearch)
        Me.Panel6.Controls.Add(Me.btnSearch)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(779, 80)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(254, 71)
        Me.Panel6.TabIndex = 6
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.White
        Me.Panel5.Controls.Add(Me.dtpkDenNgay)
        Me.Panel5.Controls.Add(Me.dtpkTuNgay)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(562, 80)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(211, 71)
        Me.Panel5.TabIndex = 5
        '
        'dtpkDenNgay
        '
        Me.dtpkDenNgay.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.dtpkDenNgay.Location = New System.Drawing.Point(0, 42)
        Me.dtpkDenNgay.Name = "dtpkDenNgay"
        Me.dtpkDenNgay.Size = New System.Drawing.Size(211, 29)
        Me.dtpkDenNgay.TabIndex = 3
        '
        'dtpkTuNgay
        '
        Me.dtpkTuNgay.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtpkTuNgay.Location = New System.Drawing.Point(0, 0)
        Me.dtpkTuNgay.Name = "dtpkTuNgay"
        Me.dtpkTuNgay.Size = New System.Drawing.Size(211, 29)
        Me.dtpkTuNgay.TabIndex = 2
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.cbbxThoiGianHD)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(262, 80)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(294, 71)
        Me.Panel4.TabIndex = 4
        '
        'btnSearch
        '
        Me.btnSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSearch.FlatAppearance.BorderSize = 0
        Me.btnSearch.Font = New System.Drawing.Font("Arial Narrow", 8.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.Image = Global.WindTown_VB.My.Resources.Resources.search
        Me.btnSearch.Location = New System.Drawing.Point(205, 19)
        Me.btnSearch.MaximumSize = New System.Drawing.Size(31, 31)
        Me.btnSearch.MinimumSize = New System.Drawing.Size(31, 31)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(31, 31)
        Me.btnSearch.TabIndex = 2
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'tbxSearch
        '
        Me.tbxSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tbxSearch.Location = New System.Drawing.Point(3, 19)
        Me.tbxSearch.Name = "tbxSearch"
        Me.tbxSearch.Size = New System.Drawing.Size(177, 29)
        Me.tbxSearch.TabIndex = 1
        '
        'cbbxThoiGianHD
        '
        Me.cbbxThoiGianHD.Dock = System.Windows.Forms.DockStyle.Top
        Me.cbbxThoiGianHD.FormattingEnabled = True
        Me.cbbxThoiGianHD.Location = New System.Drawing.Point(0, 0)
        Me.cbbxThoiGianHD.MaximumSize = New System.Drawing.Size(200, 0)
        Me.cbbxThoiGianHD.Name = "cbbxThoiGianHD"
        Me.cbbxThoiGianHD.Size = New System.Drawing.Size(200, 31)
        Me.cbbxThoiGianHD.TabIndex = 0
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.White
        Me.tlpDashboard.SetColumnSpan(Me.pnlHeader, 4)
        Me.pnlHeader.Controls.Add(Me.btnSuaHangLoat)
        Me.pnlHeader.Controls.Add(Me.btnXoaHD)
        Me.pnlHeader.Controls.Add(Me.btnSuaHD)
        Me.pnlHeader.Controls.Add(Me.btnXuatHD)
        Me.pnlHeader.Controls.Add(Me.btnThemHD)
        Me.pnlHeader.Controls.Add(Me.Label6)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlHeader.Location = New System.Drawing.Point(2, 3)
        Me.pnlHeader.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1032, 71)
        Me.pnlHeader.TabIndex = 1
        '
        'btnSuaHangLoat
        '
        Me.btnSuaHangLoat.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSuaHangLoat.BackColor = System.Drawing.Color.DimGray
        Me.btnSuaHangLoat.ForeColor = System.Drawing.Color.White
        Me.btnSuaHangLoat.Location = New System.Drawing.Point(328, 20)
        Me.btnSuaHangLoat.Name = "btnSuaHangLoat"
        Me.btnSuaHangLoat.Size = New System.Drawing.Size(160, 33)
        Me.btnSuaHangLoat.TabIndex = 5
        Me.btnSuaHangLoat.Text = "Sửa hàng loạt"
        Me.btnSuaHangLoat.UseVisualStyleBackColor = False
        '
        'btnXoaHD
        '
        Me.btnXoaHD.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXoaHD.BackColor = System.Drawing.Color.Red
        Me.btnXoaHD.ForeColor = System.Drawing.Color.White
        Me.btnXoaHD.Location = New System.Drawing.Point(494, 20)
        Me.btnXoaHD.Name = "btnXoaHD"
        Me.btnXoaHD.Size = New System.Drawing.Size(110, 33)
        Me.btnXoaHD.TabIndex = 4
        Me.btnXoaHD.Text = "Xóa"
        Me.btnXoaHD.UseVisualStyleBackColor = False
        '
        'btnSuaHD
        '
        Me.btnSuaHD.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSuaHD.BackColor = System.Drawing.Color.Gold
        Me.btnSuaHD.ForeColor = System.Drawing.Color.Black
        Me.btnSuaHD.Location = New System.Drawing.Point(610, 20)
        Me.btnSuaHD.Name = "btnSuaHD"
        Me.btnSuaHD.Size = New System.Drawing.Size(110, 33)
        Me.btnSuaHD.TabIndex = 3
        Me.btnSuaHD.Text = "Sửa"
        Me.btnSuaHD.UseVisualStyleBackColor = False
        '
        'btnXuatHD
        '
        Me.btnXuatHD.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXuatHD.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnXuatHD.ForeColor = System.Drawing.Color.White
        Me.btnXuatHD.Location = New System.Drawing.Point(726, 20)
        Me.btnXuatHD.Name = "btnXuatHD"
        Me.btnXuatHD.Size = New System.Drawing.Size(110, 33)
        Me.btnXuatHD.TabIndex = 2
        Me.btnXuatHD.Text = "Xuất"
        Me.btnXuatHD.UseVisualStyleBackColor = False
        '
        'btnThemHD
        '
        Me.btnThemHD.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnThemHD.BackColor = System.Drawing.Color.LimeGreen
        Me.btnThemHD.ForeColor = System.Drawing.Color.White
        Me.btnThemHD.Location = New System.Drawing.Point(842, 20)
        Me.btnThemHD.Name = "btnThemHD"
        Me.btnThemHD.Size = New System.Drawing.Size(180, 33)
        Me.btnThemHD.TabIndex = 1
        Me.btnThemHD.Text = "Thêm hợp đồng"
        Me.btnThemHD.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft YaHei UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(11, 20)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(224, 31)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Quản lý hợp đồng"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.cbbxTrangThai)
        Me.Panel2.Controls.Add(Me.cbbxBoPhan)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 80)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(253, 71)
        Me.Panel2.TabIndex = 2
        '
        'cbbxTrangThai
        '
        Me.cbbxTrangThai.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cbbxTrangThai.FormattingEnabled = True
        Me.cbbxTrangThai.Location = New System.Drawing.Point(0, 40)
        Me.cbbxTrangThai.Name = "cbbxTrangThai"
        Me.cbbxTrangThai.Size = New System.Drawing.Size(253, 31)
        Me.cbbxTrangThai.TabIndex = 0
        '
        'cbbxBoPhan
        '
        Me.cbbxBoPhan.Dock = System.Windows.Forms.DockStyle.Top
        Me.cbbxBoPhan.FormattingEnabled = True
        Me.cbbxBoPhan.Location = New System.Drawing.Point(0, 0)
        Me.cbbxBoPhan.Name = "cbbxBoPhan"
        Me.cbbxBoPhan.Size = New System.Drawing.Size(253, 31)
        Me.cbbxBoPhan.TabIndex = 0
        '
        'dtgvDSHopDong
        '
        Me.dtgvDSHopDong.AllowUserToAddRows = False
        Me.dtgvDSHopDong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dtgvDSHopDong.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders
        Me.dtgvDSHopDong.BackgroundColor = System.Drawing.Color.White
        Me.dtgvDSHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tlpDashboard.SetColumnSpan(Me.dtgvDSHopDong, 4)
        Me.dtgvDSHopDong.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgvDSHopDong.Location = New System.Drawing.Point(3, 157)
        Me.dtgvDSHopDong.Name = "dtgvDSHopDong"
        Me.dtgvDSHopDong.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dtgvDSHopDong.RowHeadersVisible = False
        Me.dtgvDSHopDong.RowHeadersWidth = 51
        Me.dtgvDSHopDong.RowTemplate.Height = 24
        Me.dtgvDSHopDong.Size = New System.Drawing.Size(1030, 499)
        Me.dtgvDSHopDong.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(218, 5)
        Me.Label1.MaximumSize = New System.Drawing.Size(73, 23)
        Me.Label1.MinimumSize = New System.Drawing.Size(73, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Từ ngày"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(205, 43)
        Me.Label2.MaximumSize = New System.Drawing.Size(86, 23)
        Me.Label2.MinimumSize = New System.Drawing.Size(86, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Đến ngày"
        '
        'frmHopDong
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(1040, 665)
        Me.Controls.Add(Me.tlpnlMain)
        Me.Font = New System.Drawing.Font("Microsoft YaHei UI", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "frmHopDong"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Hợp đồng"
        Me.tlpnlMain.ResumeLayout(False)
        Me.tlpDashboard.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.dtgvDSHopDong, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents tlpnlMain As TableLayoutPanel
    Friend WithEvents tlpDashboard As TableLayoutPanel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents cbbxThoiGianHD As ComboBox
    Friend WithEvents cbbxTrangThai As ComboBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents tbxSearch As TextBox
    Friend WithEvents dtpkTuNgay As DateTimePicker
    Friend WithEvents dtpkDenNgay As DateTimePicker
    Friend WithEvents btnThemHD As Button
    Friend WithEvents btnXuatHD As Button
    Friend WithEvents btnSuaHD As Button
    Friend WithEvents btnXoaHD As Button
    Friend WithEvents btnSuaHangLoat As Button
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents cbbxBoPhan As ComboBox
    Friend WithEvents dtgvDSHopDong As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class

